import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'nw-ship-order',
  templateUrl: './ship-order.component.html',
  styleUrls: ['./ship-order.component.css']
})
export class ShipOrderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
