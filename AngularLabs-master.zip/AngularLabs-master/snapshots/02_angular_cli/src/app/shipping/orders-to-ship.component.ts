import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'nw-orders-to-ship',
  templateUrl: './orders-to-ship.component.html',
  styleUrls: ['./orders-to-ship.component.css']
})
export class OrdersToShipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
