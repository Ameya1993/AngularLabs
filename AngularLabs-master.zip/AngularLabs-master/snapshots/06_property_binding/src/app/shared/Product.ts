export class Product {
  productID: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  featured: string;
}