import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-built-in-directives',
  templateUrl: './built-in-directives.component.html',
  styleUrls: ['./built-in-directives.component.css']
})
export class BuiltInDirectivesComponent implements OnInit {
  people;
  constructor() { }

  ngOnInit() {
  }

}
