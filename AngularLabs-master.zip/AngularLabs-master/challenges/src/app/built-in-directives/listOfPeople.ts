export const people = [
  { name: { first: "Samina", last: "Qazi" }, gender: "female", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAM8AAAAJDMxNGQ0YTliLTk4NjItNDgxYS1iNTg0LWFkNjI0NWU4MDFhNw.jpg" } },
  { name: { first: "Nikita", last: "Amaritya" }, gender: "female", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAugAAAAJDcwNDFlOGE2LWM2NjQtNDBjMy04OTlmLWRjN2E2MDEzMDk4Mg.jpg" } },
  { name: { first: "Charls", last: "Antony" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAANfAAAAJGZkMzliMGU2LTBlNjgtNDM2MC05YTY1LTViMjMwOTg4ZGI3Zg.jpg" } },
  { name: { first: "Snehith", last: "Desu" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAt1AAAAJDc5MjFkZDNjLWQ2ODMtNDg0YS1iODYyLTE1ZTMzNGFlMjFiOQ.jpg" } },
  { name: { first: "Greg", last: "Harris" }, gender: "male", picture: { large: "https://media-exp2.licdn.com/media/p/6/000/235/0f3/16ad0d5.jpg" } },
];