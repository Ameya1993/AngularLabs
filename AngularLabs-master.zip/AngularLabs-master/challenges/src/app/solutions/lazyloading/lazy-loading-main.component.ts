import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-lazy-loading-main',
  templateUrl: './lazy-loading-main.component.html',
  styleUrls: ['./lazy-loading-main.component.css']
})
export class LazyLoadingMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
