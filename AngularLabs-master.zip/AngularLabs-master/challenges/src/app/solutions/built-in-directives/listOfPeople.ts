export const people = [
  { name: {first: "Jaclyn", last: "Lim"}, gender: "female", picture: {large: "https://media-exp2.licdn.com/media/p/6/000/2b4/19d/057873d.jpg"}},
  { name: {first: "Tom", last: "Augustine"}, gender: "male", picture: {large: ""}},
  { name: {first: "Matt", last: "Pollock"}, gender: "male", picture: {large: "https://media-exp2.licdn.com/media/AAEAAQAAAAAAAAujAAAAJDAzZDQzYjAyLTc2NGItNDYxMS1hMzYzLTI3YzZlOWZhMjRkMw.jpg"}},
  { name: {first: "Praba", last: "Doe"}, gender: "female", picture: {large: ""}},
  { name: {first: "Marc", last: "Duarte"}, gender: "male", picture: {large: "http://static0.therichestimages.com/wp-content/uploads/2011/04/Brad_Pitt.jpg"}},
];